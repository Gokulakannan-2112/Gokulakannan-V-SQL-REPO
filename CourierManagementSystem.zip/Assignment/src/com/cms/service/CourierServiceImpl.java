package com.cms.service;

import java.sql.SQLException;
import java.util.List;

import com.cms.dao.CourierDAOImpl;
import com.cms.dao.ICourierDAO;
import com.cms.entity.Courier;
import com.cms.entity.Couriercompany;
import com.cms.entity.Employee;
import com.cms.exception.InvalidEmployeeIDException;
import com.cms.exception.TrackingNumberNotFoundException;

public class CourierServiceImpl implements ICourierService {
	
	private ICourierDAO courierdao;

	public CourierServiceImpl() {
		super();
		courierdao = new CourierDAOImpl();
	}

	@Override
	public int placeOrder(Courier courier) {
		int result=0;
		try {
			result=courierdao.placeOrder(courier);
		}catch(ClassNotFoundException cnfe) {
			System.out.println("looks like driver not found");
		}catch(SQLException se) {
			System.out.println("either url,username or password are wrong");
		}
		return result;
	}

	@Override
	public String getOrderStatus(int courierid) {
		String status=null;

		try {
			status = courierdao.getOrderStatus(courierid);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (TrackingNumberNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return status;

	}

	@Override
	public int cancelOrder(int courierid) {
		int result = 0;
		try {
			result = courierdao.cancelOrder(courierid);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (TrackingNumberNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return result;
	}

	@Override
	public List<Couriercompany> getStaffOrder(int employeeid) {
		List<Couriercompany> coList = null;

		try {
			coList = courierdao.getStaffOrder(employeeid);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (InvalidEmployeeIDException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return coList;
	}

	@Override
	public int addEmployee(Employee employee) {
		int result = 0;
		try {
			result = courierdao.addEmployee(employee);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

}
