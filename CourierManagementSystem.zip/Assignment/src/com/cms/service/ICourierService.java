package com.cms.service;

import java.util.List;

import com.cms.entity.Courier;
import com.cms.entity.Couriercompany;
import com.cms.entity.Employee;

public interface ICourierService {
	public int placeOrder(Courier courier);
	public String getOrderStatus(int courierid);
	public int cancelOrder(int courierid);
	public List<Couriercompany>getStaffOrder(int employeeid);
	public int addEmployee(Employee employee);

}
