package com.cms.entity;

public class Employee {
	private int EmployeeID;
	private String Name;
	private String Email;
	private String ContactNumber;
	private String Role;
	private double Salary;
	
	public Employee() {
		super();
	}

	public Employee(String name, String email, String contactNumber, String role, double salary) {
		super();
		Name = name;
		Email = email;
		ContactNumber = contactNumber;
		Role = role;
		Salary = salary;
	}

	public Employee(int employeeID, String name, String email, String contactNumber, String role, double salary) {
		super();
		EmployeeID = employeeID;
		Name = name;
		Email = email;
		ContactNumber = contactNumber;
		Role = role;
		Salary = salary;
	}

	public int getEmployeeID() {
		return EmployeeID;
	}

	public void setEmployeeID(int employeeID) {
		EmployeeID = employeeID;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getContactNumber() {
		return ContactNumber;
	}

	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

	public double getSalary() {
		return Salary;
	}

	public void setSalary(double salary) {
		Salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [EmployeeID=" + EmployeeID + ", Name=" + Name + ", Email=" + Email + ", ContactNumber="
				+ ContactNumber + ", Role=" + Role + ", Salary=" + Salary + "]";
	}
	
}
