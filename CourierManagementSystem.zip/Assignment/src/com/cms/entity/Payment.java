package com.cms.entity;

import java.time.LocalDate;

public class Payment extends Courier{
	private int PaymentID;
	private int courierid;
	private double Amount;
	private LocalDate PaymentDate;
	
	public Payment() {
		super();
	}

	public Payment(int paymentID, int courierid, Location location, double amount, LocalDate paymentDate) {
		super();
		PaymentID = paymentID;
		this.courierid = super.getCourierID();
		Amount = amount;
		PaymentDate = paymentDate;
	}

	public Payment(int courierid, Location location, double amount, LocalDate paymentDate) {
		super();
		this.courierid = super.getCourierID();
		Amount = amount;
		PaymentDate = paymentDate;
	}

	public int getPaymentID() {
		return PaymentID;
	}

	public void setPaymentID(int paymentID) {
		PaymentID = paymentID;
	}

	public int getCourierid() {
		return courierid;
	}

	public void setCourierid(int courierid) {
		this.courierid = courierid;
	}

	public double getAmount() {
		return Amount;
	}

	public void setAmount(double amount) {
		Amount = amount;
	}

	public LocalDate getPaymentDate() {
		return PaymentDate;
	}

	public void setPaymentDate(LocalDate paymentDate) {
		PaymentDate = paymentDate;
	}

	@Override
	public String toString() {
		return "Payment [PaymentID=" + PaymentID + ", courierid=" + courierid + ", Amount="
				+ Amount + ", PaymentDate=" + PaymentDate + "]";
	}	
	

}
