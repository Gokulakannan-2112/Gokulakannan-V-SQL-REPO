package com.cms.entity;

import java.time.LocalDate;

public class Courier extends User{
	private int CourierID;
	private String SenderName;
	private String SenderAddress;
	private String ReceiverName;
	private String ReceiverAddress;
	private double Weight;
	private String Status;
	private int TrackingNumber;
	private LocalDate DeliveryDate;
	private User user;
	
	public Courier() {
		super();
	}

	public Courier(String senderName, String senderAddress, String receiverName, String receiverAddress, double weight,
			String status, int trackingNumber, LocalDate deliveryDate, User user) {
		super();
		SenderName = senderName;
		SenderAddress = senderAddress;
		ReceiverName = receiverName;
		ReceiverAddress = receiverAddress;
		Weight = weight;
		Status = status;
		TrackingNumber = trackingNumber;
		DeliveryDate = deliveryDate;
		this.user = user;
	}

	public Courier(String senderName, String senderAddress, String receiverName, String receiverAddress, double weight,
			String status, int trackingNumber, LocalDate deliveryDate) {
		super();
		SenderName = senderName;
		SenderAddress = senderAddress;
		ReceiverName = receiverName;
		ReceiverAddress = receiverAddress;
		Weight = weight;
		Status = status;
		TrackingNumber = trackingNumber;
		DeliveryDate = deliveryDate;
	}

	public Courier(int courierID, String senderName, String senderAddress, String receiverName, String receiverAddress,
			double weight, String status, int trackingNumber, LocalDate deliveryDate,User user) {
		super();
		CourierID=courierID;
		SenderName = senderName;
		SenderAddress = senderAddress;
		ReceiverName = receiverName;
		ReceiverAddress = receiverAddress;
		Weight = weight;
		Status = status;
		TrackingNumber = trackingNumber;
		DeliveryDate = deliveryDate;
		this.user = user;
	}

	public int getCourierID() {
		return CourierID;
	}

	public void setCourierID(int courierID) {
		CourierID = courierID;
	}

	public String getSenderName() {
		return SenderName;
	}

	public void setSenderName(String senderName) {
		SenderName = senderName;
	}

	public String getSenderAddress() {
		return SenderAddress;
	}

	public void setSenderAddress(String senderAddress) {
		SenderAddress = senderAddress;
	}

	public String getReceiverName() {
		return ReceiverName;
	}

	public void setReceiverName(String receiverName) {
		ReceiverName = receiverName;
	}

	public String getReceiverAddress() {
		return ReceiverAddress;
	}

	public void setReceiverAddress(String receiverAddress) {
		ReceiverAddress = receiverAddress;
	}

	public double getWeight() {
		return Weight;
	}

	public void setWeight(double weight) {
		Weight = weight;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public int getTrackingNumber() {
		return TrackingNumber;
	}

	public void setTrackingNumber(int trackingNumber) {
		TrackingNumber = trackingNumber;
	}

	public LocalDate getDeliveryDate() {
		return DeliveryDate;
	}

	public void setDeliveryDate(LocalDate deliveryDate) {
		DeliveryDate = deliveryDate;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Courier [CourierID=" + CourierID + ", SenderName=" + SenderName + ", SenderAddress=" + SenderAddress
				+ ", ReceiverName=" + ReceiverName + ", ReceiverAddress=" + ReceiverAddress + ", Weight=" + Weight
				+ ", Status=" + Status + ", TrackingNumber=" + TrackingNumber + ", DeliveryDate=" + DeliveryDate
				+ ", user=" + user + "]";
	}

}
