package com.cms.entity;

public class Couriercompany {
	private int serviceid;
	private String Compname;
	private Courier courier;
	private Employee employee;
	private Location location;
	
	public Couriercompany() {
		super();
	}

	public Couriercompany(int serviceid,String compname, Courier courier, Employee employee, Location location) {
		super();
		this.serviceid=serviceid;
		Compname = compname;
		this.courier = courier;
		this.employee = employee;
		this.location = location;
	}

	public String getCompname() {
		return Compname;
	}

	public void setCompname(String compname) {
		Compname = compname;
	}

	public Courier getCourier() {
		return courier;
	}

	public void setCourier(Courier courier) {
		this.courier = courier;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public int getServiceid() {
		return serviceid;
	}

	public void setServiceid(int serviceid) {
		this.serviceid = serviceid;
	}

	@Override
	public String toString() {
		return "Couriercompany [serviceid=" + serviceid + ", Compname=" + Compname + ", courier=" + courier
				+ ", employee=" + employee + ", location=" + location + "]";
	}
	
}
