package com.cms.entity;

public class User {
	private int userid;
	private String name;
	private String email;
	private int password;
	private String contact;
	private String address;
	
	public User() {
		super();
	}

	public User(int userid, String name, String email, int password, String contact, String address) {
		super();
		this.userid = userid;
		this.name = name;
		this.email = email;
		this.password = password;
		this.contact = contact;
		this.address = address;
	}

	public User(String name, String email, int password, String contact, String address) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.contact = contact;
		this.address = address;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "User [userid=" + userid + ", name=" + name + ", email=" + email + ", password=" + password
				+ ", contact=" + contact + ", address=" + address + "]";
	}
	
}
