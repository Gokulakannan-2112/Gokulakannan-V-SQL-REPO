package com.cms.entity;

public class Location {
	private int LocationID;
	private String LocationName;
	private String Address;
	
	public Location() {
		super();
	}

	public Location(String locationName, String address) {
		super();
		LocationName = locationName;
		Address = address;
	}

	public Location(int locationID, String locationName, String address) {
		super();
		LocationID = locationID;
		LocationName = locationName;
		Address = address;
	}
	
	public int getLocationID() {
		return LocationID;
	}
	public void setLocationID(int locationID) {
		LocationID = locationID;
	}
	public String getLocationName() {
		return LocationName;
	}
	public void setLocationName(String locationName) {
		LocationName = locationName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}

	@Override
	public String toString() {
		return "Location [LocationID=" + LocationID + ", LocationName=" + LocationName + ", Address=" + Address + "]";
	}
	
}
