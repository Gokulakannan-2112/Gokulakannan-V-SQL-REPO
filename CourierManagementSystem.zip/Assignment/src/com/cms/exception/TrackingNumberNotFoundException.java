package com.cms.exception;

public class TrackingNumberNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TrackingNumberNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public TrackingNumberNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
