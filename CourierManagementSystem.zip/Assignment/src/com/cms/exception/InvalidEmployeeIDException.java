package com.cms.exception;

public class InvalidEmployeeIDException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidEmployeeIDException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidEmployeeIDException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
