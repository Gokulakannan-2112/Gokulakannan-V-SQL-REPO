package com.cms.main;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cms.entity.Courier;
import com.cms.entity.Couriercompany;
import com.cms.entity.Employee;
import com.cms.entity.User;
import com.cms.service.CourierServiceImpl;
import com.cms.service.ICourierService;

public class Mainmod {

	public static void main(String[] args) throws Exception {
		ICourierService orderservice=new CourierServiceImpl();
		Courier courier=null;
		User user=null;
		Employee employee=null;
		String sendern=null;
		String sendera=null;
		String receivern=null;
		String receivera=null;
		double weight=0;
		String status=null;
		int employeeid=0;
		int track=0;
		LocalDate delivery=null;
		int courierid=0;
		int custid=0;
		String empname=null;
		String email=null;
		String contact=null;
		String role=null;
		double salary=0;
		int year=0;
		int month=0;
		int dayOfMonth=0;
		int choice = -1;
		int success=0;

		Scanner sc = new Scanner(System.in);
				while (choice != 0) {
					System.out.println("Following are the options:");
					System.out.println("1. place order");
					System.out.println("2. order status");
					System.out.println("3. cancel order");
					System.out.println("4. get orders by staff");
					System.out.println("5. add new employee");
					System.out.println("0. Exit");
					System.out.print("Please enter your choice: ");

					choice = sc.nextInt();
					sc.nextLine();

					switch (choice) {
					case 1:
						System.out.print("Enter sender:");
						sendern = sc.nextLine();

						System.out.print("Enter address:");
						sendera = sc.nextLine();

						System.out.print("Enter receiver:");
						receivern = sc.nextLine();

						System.out.print("enter address:");
						receivera = sc.nextLine();

						System.out.print("Enter weight:");
						weight = sc.nextDouble();
						sc.nextLine();

						System.out.print("Enter status:");
						status = sc.nextLine();

						System.out.print("Enter teacking no:");
						track = sc.nextInt();
						sc.nextLine();
						
						System.out.println("Enter delivery Date: ");
						System.out.print("Enter year: ");
						year = Integer.parseInt(sc.nextLine());

						System.out.print("Enter month: ");
						month = Integer.parseInt(sc.nextLine());

						System.out.print("Enter day of month: ");
						dayOfMonth = Integer.parseInt(sc.nextLine());

						delivery = LocalDate.of(year, month, dayOfMonth);
						
						System.out.println("enter customerID:");
						custid=sc.nextInt();
						sc.nextLine();
						user=new User();
						user.setUserid(custid);
						
						courier=new Courier(sendern,sendera,receivern,receivera,weight,status,track,delivery,user);
						
						success = orderservice.placeOrder(courier);

						if (success == 1) {
							System.out.println("Record inserted successfully...");
						}
						break;

					case 2:
						System.out.print("Enter courier ID: ");
						courierid = sc.nextInt();
						sc.nextLine();

						status = orderservice.getOrderStatus(courierid);

						if (status == null) {
							System.out.println("No such courier");
						} else {
							System.out.println("The courier status: ");
							System.out.println(status);
						}
						break;
					case 3:
						System.out.print("Enter courier ID: ");
						courierid = sc.nextInt();
						sc.nextLine();

						success = orderservice.cancelOrder(courierid);

						if (success == 0) {
							System.out.println("No such courier");
						} else {
							System.out.println("Record is deleted successfully...");
						}
						break;
					case 4:
						System.out.println("enter employee id:");
						employeeid=sc.nextInt();
						sc.nextLine();
						List<Couriercompany> coList = orderservice.getStaffOrder(employeeid);
						if (coList == null) {
							System.out.println("No couriers for that employee.");
						} else {
							System.out.println("Following are the couriers:");

							for (Couriercompany couriercompany : coList) {
								System.out.println(couriercompany);
							}
						}
						break;
					case 5:
						System.out.print("Enter name:");
						empname = sc.nextLine();

						System.out.print("Enter email:");
						email = sc.nextLine();

						System.out.print("Enter contact:");
						contact = sc.nextLine();

						System.out.print("enter role (admin or user) :");
						role = sc.nextLine();

						System.out.print("Enter salary:");
						salary = sc.nextDouble();
						sc.nextLine();
						
						employee=new Employee(empname,email,contact,role,salary);
												
						success = orderservice.addEmployee(employee);

						if (success == 1) {
							System.out.println("Record inserted successfully...");
						}
						break;

					case 0:
						System.out.println("You have chosen to exit.");
						break;
					default:
						System.out.println("Incorrect option");
						break;
					}
				}
		sc.close();
	}
}
