package com.cms.tasks;

public class Task9 {
    public static void main(String[] args) {
        validate("John", "name");
        validate("123 Main Street", "address");
        validate("555-123-4567", "phone number");
    }

    public static void validate(String data, String detail) {
        if (detail.equalsIgnoreCase("name")) {
            if (isValidName(data)) {
                System.out.println("Name is valid: " + data);
            } else {
                System.out.println("Invalid name: " + data);
            }
        } else if (detail.equalsIgnoreCase("address")) {
            if (isValidAddress(data)) {
                System.out.println("Address is valid: " + data);
            } else {
                System.out.println("Invalid address: " + data);
            }
        } else if (detail.equalsIgnoreCase("phone number")) {
            if (isValidPhoneNumber(data)) {
                System.out.println("Phone number is valid: " + data);
            } else {
                System.out.println("Invalid phone number: " + data);
            }
        } else {
            System.out.println("Invalid detail type: " + detail);
        }
    }

    private static boolean isValidName(String name) {
        return name.matches("^[A-Z][a-z]*$");
    }

    private static boolean isValidAddress(String address) {
        return address.matches("^[a-zA-Z0-9\\s]*$");
    }

    private static boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("^\\d{3}-\\d{3}-\\d{4}$");
    }
}
