package com.cms.tasks;

public class Task {
	private int shippinglocationcode;
	private int deliverylocationcode;
	private int mincount=0;
	
	public Task(int courierid, int trackno, int shippinglocationcode, int deliverylocationcode) {
		super();
		this.shippinglocationcode = shippinglocationcode;
		this.deliverylocationcode = deliverylocationcode;
	}
	
	public void track() {
		while(shippinglocationcode==deliverylocationcode) {
			System.out.println("Arrived at the location");
		}
		while(shippinglocationcode!=deliverylocationcode) {
			shippinglocationcode++;
			mincount++;
			}
		System.out.println("time taken to deliver :"+mincount+" minutes");
	}
	public static void main(String[] args) {
		Task c1=new Task(1,3001,641001,641045);
		Task c2=new Task(2,3002,641001,641016);
		Task c3=new Task(3,3003,641001,641008);
		c1.track();
		c2.track();
		c3.track();

	}

}

