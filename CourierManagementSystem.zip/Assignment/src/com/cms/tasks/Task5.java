package com.cms.tasks;

import java.util.Scanner;

public class Task5 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter cust id: ");
		int id=sc.nextInt();
		int count=0;
		int ordersID[]=new int[] {1001,1002,1003,1004,1005};
		for (int i = 0; i < ordersID.length; i++) {
			if(ordersID[i]%id==0) {
				System.out.println("CourierID for "+id+" is "+ordersID[i]);
				count++;
			}
		}
		System.out.println("total couriers: "+count);
		sc.close();
	}
}