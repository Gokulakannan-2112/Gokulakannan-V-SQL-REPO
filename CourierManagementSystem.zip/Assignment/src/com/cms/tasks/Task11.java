package com.cms.tasks;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Task11 {
    public static void main(String[] args) {
        String customerName = "Gokulakannan";
        int orderNumber = 123456;
        String Address = "123 Main Street, Coimbatore, Tamilnadu, 12345";
        Date DeliveryDate = new Date();

        String confirmationEmail = generateEmail(customerName, orderNumber, Address, DeliveryDate);
        System.out.println(confirmationEmail);
    }

    public static String generateEmail(String customerName, int orderNumber, String Address, Date DeliveryDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMMM dd, yyyy");

        StringBuilder emailContent = new StringBuilder();
        emailContent.append("Subject: Order Confirmation\n\n");
        emailContent.append("Dear ").append(customerName).append(",\n\n");
        emailContent.append("Thank you for your order!\n");
        emailContent.append("Your order with order number ").append(orderNumber).append(" has been confirmed and is scheduled for delivery.\n");
        emailContent.append("Delivery Address: ").append(Address).append("\n");
        emailContent.append("Expected Delivery Date: ").append(dateFormat.format(DeliveryDate)).append("\n\n");
        emailContent.append("Please feel free to contact us if you have any questions.\n");
        emailContent.append("Thank you for choosing our courier services!\n\n");
        emailContent.append("Sincerely,\nThe Courier Management Team");

        return emailContent.toString();
    }
}
