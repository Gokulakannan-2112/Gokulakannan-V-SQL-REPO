package com.cms.tasks;

import java.util.Scanner;

public class Task8 {
	public static void main(String[] args) {
		String[][] trackingInfo = { { "TN123", "In Transit" }, { "TN456", "Out for Delivery" },
				{ "TN789", "Delivered" } };

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter a new parcel tracking number: ");
		String newTrackingNumber = scanner.nextLine();
		int index = findTrackingNumberIndex(trackingInfo, newTrackingNumber);
		if (index != -1) {
			System.out.println("Current Status for " + newTrackingNumber + ": " + trackingInfo[index][1]);
			simulateTrackingProcess(trackingInfo, index);
		} else {
			System.out.println("Tracking number not found.");
		}
		scanner.close();
	}

	private static int findTrackingNumberIndex(String[][] trackingInfo, String trackingNumber) {
		for (int i = 0; i < trackingInfo.length; i++) {
			if (trackingInfo[i][0].equals(trackingNumber)) {
				return i;
			}
		}
		return -1;
	}

	private static void simulateTrackingProcess(String[][] trackingInfo, int index) {
		String currentStatus = trackingInfo[index][1];

		switch (currentStatus) {
		case "In Transit":
			System.out.println("Parcel in transit");
			trackingInfo[index][1] = "Out for Delivery";
			break;
		case "Out for Delivery":
			System.out.println("Parcel out for delivery");
			trackingInfo[index][1] = "Delivered";
			break;
		case "Delivered":
			System.out.println("Parcel already delivered");
			break;
		default:
			System.out.println("Invalid status.");
		}

		System.out.println();
	}
}
