package com.cms.tasks;

import java.util.Scanner;

public class Task7 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the total couriers: ");
		int n=sc.nextInt();
		boolean ch=false;
		int arr[]=new int[n];
		System.out.println("Enter couriers: ");
		for (int i = 0; i < arr.length; i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("enter new order: ");
		int New=sc.nextInt();
		for (int i = 0; i < arr.length; i++) {
			if(New+2 == arr[i] || New-2 == arr[i]) {
				System.out.println("nearest is "+arr[i]);
				ch=true;
			}
		}
		if(ch==false) {
			System.out.println("no nearest couriers");
		}
		sc.close();
	}
}
