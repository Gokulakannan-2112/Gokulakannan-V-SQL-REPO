package com.cms.tasks;
import java.util.Scanner;
public class Task1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String order1 = sc.next();
		if (order1 == "processing") {
			System.out.println("order1 not delivered");
		} else if (order1 == "cancelled") {
			System.out.println("order1 not delivered");
		} else if (order1 == "delivered") {
			System.out.println("order1 delivered");
		}
		sc.close();
	}
}
