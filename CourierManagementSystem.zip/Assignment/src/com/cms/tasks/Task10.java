package com.cms.tasks;

import java.util.Scanner;

public class Task10 {
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter street:");
    	String street=sc.nextLine();
    	System.out.println("Enter city:");
    	String city=sc.next();
    	System.out.println("Enter state:");
    	String state=sc.next();
    	System.out.println("Enter zipcode:");
    	String zipcode=sc.next();
        String formattedAddress = formatAddress(street,city,state,zipcode);
        System.out.println("Formatted Address: " + formattedAddress);
        sc.close();
    }
    public static String formatAddress(String street, String city, String state, String zipCode) {
        street = capitalizeEachWord(street);
        city = capitalizeEachWord(city);
        state = capitalizeEachWord(state);
        if (isValidZipCode(zipCode)) {
            if (zipCode.length() == 9) {
                return street + ", " + city + ", " + state + " " + zipCode.substring(0, 5) + "-" + zipCode.substring(5);
            } else {
                return street + ", " + city + ", " + state + " " + zipCode;
            }
        } else {
            return "Invalid zip code";
        }
    }

    private static String capitalizeEachWord(String input) {
        String[] words = input.split("\\s");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            result.append(word.substring(0, 1).toUpperCase()).append(word.substring(1)).append(" ");
        }
        return result.toString().trim();
    }

    private static boolean isValidZipCode(String zipCode) {
        return zipCode.matches("^\\d{5}(?:-\\d{4})?$");
    }
}

