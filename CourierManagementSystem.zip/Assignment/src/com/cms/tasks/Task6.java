package com.cms.tasks;

import java.util.Scanner;

public class Task6 {
	
	public static String track(int trackid,int n,String location) {	
		return "Location of "+trackid+" is "+location;
	}
	
	public static void main(String[] args) {
		int TrackHistory[]=new int[] {115,223,409,812};
		int size=TrackHistory.length;
		String Locations[]=new String[size];
		Scanner sc=new Scanner(System.in);
		for (int i = 0; i < Locations.length; i++) {
			System.out.println("enter the location for "+TrackHistory[i]+" :");
			Locations[i]=sc.next();
		}
		for (int i = 0; i < TrackHistory.length; i++) {
			System.out.println(track(TrackHistory[i],size,Locations[i]));
		}
		sc.close();
	}
}
