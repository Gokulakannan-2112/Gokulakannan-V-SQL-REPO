package com.cms.tasks;

import java.util.Scanner;

public class Task2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter order1 weight: ");
		int order1 = sc.nextInt();
		System.out.println("Enter order2 weight: ");
		int order2 = sc.nextInt();
		System.out.println("Enter order3 weight: ");
		int order3 = sc.nextInt();
		switch (order1) {
		case 200:
			System.out.println("Light");
			break;
		case 500:
			System.out.println("Medium");
			break;
		case 700:
			System.out.println("Heavy");
			break;
		}
		switch (order2) {
		case 200:
			System.out.println("Light");
			break;
		case 500:
			System.out.println("Medium");
			break;
		case 700:
			System.out.println("Heavy");
			break;
		}
		switch (order3) {
		case 200:
			System.out.println("Light");
			break;
		case 500:
			System.out.println("Medium");
			break;
		case 700:
			System.out.println("Heavy");
			break;
		}
		sc.close();
	}
}
