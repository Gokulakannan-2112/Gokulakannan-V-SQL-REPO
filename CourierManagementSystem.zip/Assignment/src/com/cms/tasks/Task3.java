package com.cms.tasks;

import java.util.Scanner;

public class Task3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter choice");
		System.out.println("1.employee login");
		System.out.println("2.customer login");
		int choice = sc.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter employee name: ");
			String name = sc.next();
			System.out.println("Enter password(six digits): ");
			int password = sc.nextInt();
			int count = 0;
			while (password != 0) {
				password = password / 10;
				count++;
			}
			if (count <= 5 || count > 6) {
				System.out.println("password not valid");
			} else {
				System.out.println("welcome " + name + " to employee page!!");
			}
			break;
		case 2:
			System.out.println("Enter user name: ");
			String custname = sc.next();
			System.out.println("Enter password(six digits): ");
			int pwd = sc.nextInt();
			int ct = 0;
			while (pwd != 0) {
				pwd = pwd / 10;
				ct++;
			}
			if (ct <= 5 || ct > 6) {
				System.out.println("password not valid");
			} else {
				System.out.println("welcome " + custname + " to customer page!!");
			}
			break;
		default:
			System.out.println("Incorrect option");
		}

		sc.close();
	}
}
