package com.cms.tasks;

import java.util.Scanner;

public class Task12 {
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter source address:");
    	String sourceAddress = sc.nextLine();
    	System.out.println("Enter destination address:");
    	String destinationAddress = sc.next();
    	System.out.println("Enter distance:");
        double distance = sc.nextDouble(); 
        System.out.println("Enter weight:");
        double weight = sc.nextDouble(); 

        double shippingCost = calculate(sourceAddress, destinationAddress, distance, weight);
        System.out.println("Shipping Cost: " + shippingCost+" Rupees");
        sc.close();
    }

    public static double calculate(String sourceAddress, String destinationAddress, double distance, double weight) {
        double RatePerKilometer = 0.1;
        double weightRate = 0.5;
        double baseCost = RatePerKilometer * distance;
        double weightCost = weightRate * weight;
        return baseCost + weightCost;
    }
}

