package com.cms.dao;

import java.sql.SQLException;
import java.util.List;

import com.cms.entity.Courier;
import com.cms.entity.Couriercompany;
import com.cms.entity.Employee;
import com.cms.exception.InvalidEmployeeIDException;
import com.cms.exception.TrackingNumberNotFoundException;

public interface ICourierDAO {
	public int placeOrder(Courier courier)throws ClassNotFoundException,SQLException;
	public String getOrderStatus(int courierid)throws ClassNotFoundException,SQLException,TrackingNumberNotFoundException;
	public int cancelOrder(int courierid)throws ClassNotFoundException,SQLException,TrackingNumberNotFoundException;
	public List<Couriercompany>getStaffOrder(int employeeid)throws ClassNotFoundException,SQLException,InvalidEmployeeIDException;
	public int addEmployee(Employee employee)throws ClassNotFoundException,SQLException;

}
