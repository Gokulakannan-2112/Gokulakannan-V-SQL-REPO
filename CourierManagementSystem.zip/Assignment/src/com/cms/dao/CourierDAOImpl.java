package com.cms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cms.entity.Courier;
import com.cms.entity.Couriercompany;
import com.cms.entity.Employee;
import com.cms.entity.Location;
import com.cms.entity.User;
import com.cms.exception.InvalidEmployeeIDException;
import com.cms.exception.TrackingNumberNotFoundException;
import com.cms.util.DBUtil;

public class CourierDAOImpl implements ICourierDAO {
	private static Connection connCourier;

	@Override
	public int placeOrder(Courier courier) throws ClassNotFoundException, SQLException {
		connCourier = DBUtil.createConnection();
		String query="INSERT INTO courier(senderName,senderAddress,receiverName,receiverAddress,weight,status,"
				+ "trackingNumber,deliveryDate,userID) "
				+ "VALUES(?,?,?,?,?,?,?,?,?)";
		
		Date delivery=Date.valueOf(courier.getDeliveryDate());
		
		PreparedStatement preparest=connCourier.prepareStatement(query);
		preparest.setString(1, courier.getSenderName());
		preparest.setString(2, courier.getSenderAddress());
		preparest.setString(3, courier.getReceiverName());
		preparest.setString(4, courier.getReceiverAddress());
		preparest.setDouble(5, courier.getWeight());
		preparest.setString(6, courier.getStatus());
		preparest.setInt(7, courier.getTrackingNumber());
		preparest.setDate(8, delivery);
		preparest.setInt(9, courier.getUser().getUserid());

		int result=preparest.executeUpdate();
		DBUtil.closeConnection();
		return result;
	}

	@Override
	public String getOrderStatus(int courierid)
			throws ClassNotFoundException, SQLException, TrackingNumberNotFoundException {
		String status=null;
		Courier courier=null;

		String sendern=null;
		String sendera=null;
		String receivern=null;
		String receivera=null;
		double weight=0;
		int track=0;
		LocalDate delivery=null;
		int custid=0;
		
		User user=null;

		connCourier = DBUtil.createConnection();
		
		  String queryCheck =
		  "SELECT senderName,senderAddress,receiverName,receiverAddress,weight,status,trackingNumber,"
		  + "deliveryDate,userID " +
		  "FROM courier "+
		  "WHERE courierID = ?";
		 
	
		PreparedStatement prepareSt = connCourier.prepareStatement(queryCheck);
		prepareSt.setInt(1, courierid);

		ResultSet rs = prepareSt.executeQuery();

		while (rs.next()) {// Till there are further records.
			sendern = rs.getString("senderName");
			sendera = rs.getString("senderAddress");
			receivern = rs.getString("receiverName");
			receivera =  rs.getString("receiverAddress");
			delivery = rs.getDate("deliveryDate").toLocalDate();
			weight = rs.getDouble("weight");
			track = rs.getInt("trackingNumber");
			custid = rs.getInt("userID");
			status = rs.getString("status");

			user = new User();
			user.setUserid(custid);

			courier = new Courier(courierid, sendern, sendera, receivern, receivera, weight,status,track,delivery,user);
		}
		DBUtil.closeConnection();

		if (courier == null) {
			throw new TrackingNumberNotFoundException("no such courier");
		}

		return status;

	}

	@Override
	public int cancelOrder(int courierid) throws ClassNotFoundException, SQLException, TrackingNumberNotFoundException {
		Courier courier = null;
		String sendern=null;
		String sendera=null;
		String receivern=null;
		String receivera=null;
		double weight=0;
		int track=0;
		LocalDate delivery = null;

		connCourier = DBUtil.createConnection();

		String queryCheck = "SELECT * FROM courier WHERE courierID = ?";
		String queryDelete = "DELETE FROM courier WHERE courierID = ?";

		String status = null;

		int success = 0;

		PreparedStatement prepareStCourier = connCourier.prepareStatement(queryCheck);
		PreparedStatement prepareStDelete = connCourier.prepareStatement(queryDelete);

		prepareStCourier.setInt(1, courierid);
		prepareStDelete.setInt(1, courierid);

		ResultSet rs = prepareStCourier.executeQuery();

		while (rs.next()) {// Till there are further records.
			courierid = rs.getInt("courierID");
			sendern = rs.getString("senderName");
			sendera = rs.getString("senderAddress");
			receivern = rs.getString("receiverName");
			receivera = rs.getString("receiverAddress");
			weight = rs.getDouble("weight");
			track = rs.getInt("trackingNumber");
			delivery = rs.getDate("deliveryDate").toLocalDate();
			status = rs.getString("status");

			courier = new Courier(sendern, sendera, receivern, receivera, weight,status,track,delivery);
		}

		if (courier == null) {
			throw new TrackingNumberNotFoundException("No courier Found");
		} else {
			success = prepareStDelete.executeUpdate();
		}
		DBUtil.closeConnection();
		return success;

	}

	@Override
	public List<Couriercompany> getStaffOrder(int employeeid)
			throws ClassNotFoundException, SQLException, InvalidEmployeeIDException {
		List<Couriercompany> couriers = new ArrayList<>();
		Couriercompany cc=null;
		String name=null;
		Courier courier=null;
		int courierid=0;
		Employee employee=null;
		int serviceid=0;
		Location location=null;
		int locationid=0;

		connCourier = DBUtil.createConnection();

		String query = "SELECT * FROM courierservices WHERE employeeID=?";

		PreparedStatement prepareSt = connCourier.prepareStatement(query);
		prepareSt.setInt(1,employeeid);

		ResultSet rs = prepareSt.executeQuery();

		while (rs.next()) {// Till there are further records.
			courierid = rs.getInt("courierID");
			employeeid = rs.getInt("employeeID");
			serviceid = rs.getInt("serviceID");
			name = rs.getString("name");
			locationid=rs.getInt("locationID");
			
			courier=new Courier();
			courier.setCourierID(courierid);
			employee=new Employee();
			employee.setEmployeeID(employeeid);
			location=new Location();
			location.setLocationID(locationid);

			cc=new Couriercompany(serviceid,name,courier,employee,location);
			couriers.add(cc);
		}
		DBUtil.closeConnection();

		if (couriers.size() == 0) {
			throw new InvalidEmployeeIDException("No couriers Found");
		}

		return couriers;

	}

	@Override
	public int addEmployee(Employee employee) throws ClassNotFoundException, SQLException {
		connCourier = DBUtil.createConnection();
		String query = "INSERT INTO employee(employeeName, email, contactNumber, role,salary) " + "VALUES(?,?,?,?,?)";

		PreparedStatement prepareSt = connCourier.prepareStatement(query);
		prepareSt.setString(3, employee.getContactNumber());
		prepareSt.setString(4, employee.getRole());
		prepareSt.setString(2, employee.getEmail());
		prepareSt.setString(1, employee.getName());
		prepareSt.setDouble(5, employee.getSalary());

		int result = prepareSt.executeUpdate();

		DBUtil.closeConnection();
		return result;
	}

}
